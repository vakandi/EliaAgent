---
name: mcp-cli
description: Access external services via mcp-cli wrapper (WhatsApp, Telegram, Discord, Jira, SSH, Gmail). Use skill(name="mcp-cli") to load this skill before calling any mcp-cli commands.
---

# MCP-CLI Skill

## ⚠️ CRITICAL: How to Call

**ALWAYS use the `bash` tool** to execute mcp-cli commands:

```
<invoke name="bash">
  <command>mcp-cli call <server> <tool> '<json-arguments>'</command>
</invoke>
```

## Available Servers & Tools

### Telegram
```bash
mcp-cli call telegram get_default_group_messages '{"limit":20}'
mcp-cli call telegram send_msg_to_default_group '{"message":"Hello"}'
mcp-cli call telegram get_personal_dms_only '{"limit":20}'
mcp-cli call telegram send_msg_to_recipient '{"recipient":"@username","message":"..."}'
```

### WhatsApp
```bash
mcp-cli call whatsapp list_chats '{"limit":20}'
mcp-cli call whatsapp list_messages '{"chat_jid":"120363408208578679@g.us","limit":30}'
mcp-cli call whatsapp send_message '{"recipient":"120363420711538035@g.us","message":"Hello"}'
mcp-cli call whatsapp download_media '{"message_id":"...","chat_jid":"..."}'
```

### Jira
```bash
mcp-cli call mcp-atlassian create_issue '{"project":"BEN","summary":"...","description":"...","issue_type":"Task"}'
mcp-cli call mcp-atlassian jira_get_project_issues '{"project_key":"BEN"}'
```

### Discord
```bash
mcp-cli call discord-mcp discord_get_dms '{"limit":10}'
mcp-cli call discord-mcp discord_send_dm '{"user_id":"...","message":"..."}'
```

### SSH (Multi-SaaS Server)
```bash
# CORRECT server name: ssh-server-multisaasdeploy
mcp-cli call ssh-server-multisaasdeploy execute-command '{"cmdString":"docker ps"}'
mcp-cli call ssh-server-multisaasdeploy execute-command '{"cmdString":"ls -la /app"}'
```

### Gmail
```bash
mcp-cli call gmail search_emails '{"query":"in:inbox newer_than:7d","maxResults":20}'
mcp-cli call gmail send_email '{"to":["email@example.com"],"subject":"Subject","body":"Body"}'
```

## Common Issues

| Issue | Solution |
|-------|----------|
| `SERVER_NOT_FOUND: ssh-mpc-server...` | Use correct name: `ssh-server-multisaasdeploy` (NOT `ssh-mpc-server-multisaasdeploy`) |
| Tool not found | Check server name spelling exactly |

## Business Groups (WhatsApp JIDs)
- COBOU PowerRangers: `120363420711538035@g.us`
- B2LUXE BUSINESS: `120363408208578679@g.us`
- MAYAVANTA: `120363405622746597@g.us`

## Jira Projects
- Bene2Luxe: `BEN`
- CoBou Agency: `COBOUAGENC`
- TikTok/YouTube: `TIKYT`
- ZovaBoost: `ZOVAPANEL`
